import React from 'react';

const Cards=()=>{

    console.log("this is by cards ");

    return(
        <div>
            this is sample
        </div>
    )

}

export default Cards