import React from 'react';

const ScheduleNavbar = ({io}) => {
    console.log("this is asmapel");
    return ( 
        <div className="ScheduleNavbar-container">
            <h2>Schedule :</h2>
        </div>
     );
}
 
export default ScheduleNavbar;